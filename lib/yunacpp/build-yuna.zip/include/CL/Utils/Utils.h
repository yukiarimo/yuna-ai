#pragma once

// OpenCL Utils includes
#include "OpenCLUtils_Export.h"

#include <CL/Utils/Error.h>
#include <CL/Utils/File.h>
#include <CL/Utils/Context.h>

// OpenCL includes
#include <CL/cl.h>
