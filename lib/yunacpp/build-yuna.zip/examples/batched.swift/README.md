This is a swift clone of `examples/batched`.

$ `make`
$ `./swift MODEL_PATH [PROMPT] [PARALLEL]`
